
import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        BancoDeDados bancoDeDados = new BancoDeDados();

        // Cria um novo usuário e cadastra no banco de dados
        Usuario novoUsuario = new Usuario("joao123", "senha123");
        bancoDeDados.cadastrarUsuario(novoUsuario);

        // Outras funcionalidades do sistema podem ser adicionadas aqui
    }
}
