
import java.util.ArrayList;
import java.util.List;


class BancoDeDados {
    private final List<Usuario> usuario = new ArrayList<>();

    public void cadastrarUsuario(Usuario usuario) {
        usuario.add(usuario);
    }
}
